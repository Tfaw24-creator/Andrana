#!/bin/bash

# Définition des variables
APP_NAME="DemoServlet" # Nom de l'application qui sera utilisé pour générer le fichier .war
SRC_DIR="src/main/java" # Répertoire contenant les fichiers source Java
WEB_DIR="src/main/webapp" # Répertoire contenant les fichiers web (web.xml, JSP, etc.)
BUILD_DIR="build" # Répertoire temporaire pour les fichiers compilés et assemblés
LIB_DIR="lib" # Répertoire contenant les bibliothèques nécessaires (ex. servlet-api.jar)
TOMCAT_WEBAPPS="chemin/vers/webapp/de/tomcat" # Chemin vers le répertoire webapps de Tomcat
SERVLET_API_JAR="$LIB_DIR/servlet-api.jar" # Chemin vers la bibliothèque servlet-api.jar

# Nettoyage et création du répertoire temporaire pour le build
echo "Étape 1 : Nettoyage du répertoire build..."
rm -rf $BUILD_DIR # Suppression du répertoire build s'il existe
mkdir -p $BUILD_DIR/WEB-INF/classes # Création des sous-répertoires nécessaires
echo "Répertoire build nettoyé et recréé."

# Compilation des fichiers source Java
echo "Étape 2 : Compilation des fichiers source Java..."
find $SRC_DIR -name "*.java" > sources.txt # Génération de la liste des fichiers source
javac -cp $SERVLET_API_JAR -d $BUILD_DIR/WEB-INF/classes @sources.txt # Compilation des sources
if [ $? -eq 0 ]; then
    echo "Compilation réussie."
else
    echo "Erreur lors de la compilation." >&2
    exit 1
fi
rm sources.txt # Suppression du fichier temporaire contenant la liste des sources

# Copie des fichiers web (ex. web.xml, JSP, etc.) dans le répertoire build
echo "Étape 3 : Copie des fichiers web..."
cp -r $WEB_DIR/* $BUILD_DIR/ # Copie de tout le contenu du répertoire web
if [ $? -eq 0 ]; then
    echo "Fichiers web copiés avec succès."
else
    echo "Erreur lors de la copie des fichiers web." >&2
    exit 1
fi

# Génération du fichier WAR
echo "Étape 4 : Génération du fichier WAR..."
cd $BUILD_DIR || { echo "Erreur : Impossible d'accéder au répertoire build." >&2; exit 1; }
jar -cvf $APP_NAME.war * # Création du fichier WAR à partir du contenu du répertoire build
if [ $? -eq 0 ]; then
    echo "Fichier WAR généré : $APP_NAME.war"
else
    echo "Erreur lors de la génération du fichier WAR." >&2
    exit 1
fi

# Déploiement du fichier WAR dans le répertoire webapps de Tomcat
echo "Étape 5 : Déploiement dans le répertoire webapps de Tomcat..."
cp -f $BUILD_DIR/$APP_NAME.war $TOMCAT_WEBAPPS/ # Copie du fichier WAR dans le répertoire webapps de Tomcat
if [ $? -eq 0 ]; then
    echo "Déploiement terminé avec succès."
else
    echo "Erreur lors du déploiement du fichier WAR." >&2
    exit 1
fi

# Message de fin
echo ""
echo "Déploiement terminé avec succès. Redémarrez Tomcat si nécessaire."
echo ""
