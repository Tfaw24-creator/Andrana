
package classe ;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FormEmpServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {


        if (req.getParameter("id") == null) {

            try {
                List<Dept> departements = Dept.getAll() ;
                req.setAttribute("departements", departements);
                RequestDispatcher dispatcher = req.getRequestDispatcher("/form-Emp.jsp");
                dispatcher.forward(req, res);

            } catch (Exception e) {
                throw new ServletException(e) ;
            }

            
        }
        else{
            try {
                String a = req.getParameter("id") ;
                int id = Integer.parseInt(a) ;
                Emp emp = Emp.getById(id) ;
                req.setAttribute("employe", emp);
                List<Dept> departements = Dept.getAll() ;
                req.setAttribute("departements", departements);
                RequestDispatcher dispatcher = req.getRequestDispatcher("/form-Emp.jsp");
                dispatcher.forward(req, res);
            } catch (Exception e) {
                throw new ServletException(e) ;
            }

        }
        

    }
    
    
}
