package classe ;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class DeptServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        //PrintWriter out = res.getWriter();
        String a = req.getParameter("dept") ;
        Dept D = new Dept(a) ;
        try {
            D.Save();
            RequestDispatcher dispatcher = req.getRequestDispatcher("/form-Dept.html");
            dispatcher.forward(req, res);
        } catch (Exception e) {
            throw new ServletException(e) ;
        }
   
   
    }
}
