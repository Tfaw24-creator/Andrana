package classe;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Dept {
    int id;
    String name;

    public void setId(int i) {
        this.id = i;
    }

    public int getId() {
        return this.id;
    }

    public void setName(String n) {
        this.name = n;
    }

    public String getName() {
        return this.name;
    }

    public Dept(String a) {
        this.name = a;
    }

    public Dept(String a, int i) {
        this.name = a;
        this.id = i;
    }


    public static void addDept(Dept dept) throws SQLException {
        String sql = "INSERT INTO Dept (name) VALUES (?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, dept.getName());
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'ajout du département : " + e.getMessage());
            throw e;  
        }
    }


    public void Save() throws SQLException {
        try {
            addDept(this);
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'enregistrement du département : " + e.getMessage());
            throw e;  
        }
    }

    public static List<Dept> getAll() throws SQLException {
        List<Dept> departments = new ArrayList<>();
        String sql = "SELECT * FROM Dept";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Dept dept = new Dept(rs.getString("name"), rs.getInt("id"));
                departments.add(dept);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération des départements : " + e.getMessage());
            throw e; 
        }
        return departments;
    }

    public static Dept getDeptById(int id) throws SQLException {
        Dept dept = null;
        String sql = "SELECT * FROM Dept WHERE id = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    dept = new Dept(rs.getString("name"), rs.getInt("id"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération du département avec l'ID " + id + " : " + e.getMessage());
            throw e;  
        }
        return dept;
    }
}
