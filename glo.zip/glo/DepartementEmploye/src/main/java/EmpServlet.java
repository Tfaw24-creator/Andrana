package classe ;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EmpServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        //PrintWriter out = res.getWriter();
              
        if(req.getParameter("id") == null) {
            try {
                List<Emp> e = Emp.getAll() ;
                req.setAttribute("employes", e);
                RequestDispatcher dispatcher = req.getRequestDispatcher("/list-Emp.jsp");
                dispatcher.forward(req, res);
                
            } catch (Exception e) {
                throw new ServletException(e) ;
            }   
        }
        else{
            try {
                String a = req.getParameter("id") ;
                int id = Integer.parseInt(a) ;
                Emp.Delete(id);
                res.sendRedirect("employe");

            } catch (Exception e) {
                throw new ServletException(e) ;
            }

        }

    }


    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {


        if (req.getParameter("id")== null) {
            String a = req.getParameter("dept") ;
            String b = req.getParameter("name") ;
            try {
            Emp e = new Emp(Dept.getDeptById(Integer.parseInt(a)), b) ;
            e.Save();
             
            res.sendRedirect("form-emp");
                
            } catch (Exception e) {
                throw new ServletException(e) ;
            }
            
        }
        else{
            int id = Integer.parseInt(req.getParameter("id")) ;
            String name = req.getParameter("name") ;
            int  dept = Integer.parseInt(req.getParameter("dept")) ;
            try {
            Emp.modifEmp(id,name,dept) ;

            res.sendRedirect("employe");
                
            } catch (Exception e) {
                throw new ServletException(e) ;
            }
        }

        

       
    }


    

}
