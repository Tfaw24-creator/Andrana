package classe;

import java.rmi.server.ExportException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Emp {
    private int id;
    private Dept departement;
    private String name;

    public Emp(int id, Dept departement, String name) {
        this.id = id;
        this.departement = departement;
        this.name = name;
    }
    
    public Emp(Dept departement, String name) {
        this.departement = departement;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Dept getDepartement() {
        return departement;
    }

    public void setDepartement(Dept departement) {
        this.departement = departement;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public static void addEmp(Emp emp) throws SQLException {
        String sql = "INSERT INTO Emp (name, idDept) VALUES (?, ?)";
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, emp.getName());
            stmt.setInt(2, emp.getDepartement().getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'ajout de l'employé : " + e.getMessage());
            throw e;  
        }
    }

    public void Save() throws SQLException {
        try {
            addEmp(this);
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'enregistrement de l'employé : " + e.getMessage());
            throw e;  
        }
    }

    public static List<Emp> getAll() throws SQLException {
        List<Emp> employees = new ArrayList<>();
        String sql = "SELECT e.id, e.name, d.id AS deptId, d.name AS deptName FROM Emp e JOIN Dept d ON e.idDept = d.id";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Dept dept = new Dept(rs.getString("deptName"), rs.getInt("deptId"));
                Emp emp = new Emp(rs.getInt("id"), dept, rs.getString("name"));
                employees.add(emp);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération des employés : " + e.getMessage());
            throw e; 
        }
        return employees;
    }

    public static Emp getById(int id) throws Exception {
        Emp emp = null;
        String sql = "SELECT id, name, idDept FROM Emp WHERE id = ?";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Dept temp = Dept.getDeptById(rs.getInt("idDept"));
                    emp = new Emp(rs.getInt("id"), temp, rs.getString("name"));
                }
            }
        } catch (Exception e) {
            throw e;
        }
        return emp;
    }
    

    public static void modifEmp(int id , String name ,int idDept) throws SQLException {
        String sql = "UPDATE Emp SET name = ?, idDept = ? WHERE id = ?";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, name);
            stmt.setInt(2, idDept);
            stmt.setInt(3, id);

            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Erreur lors de la modification de l'employé : " + e.getMessage());
            throw e;
        }
    }

    public static void Delete(int id) throws SQLException {
        String sql = "DELETE FROM Emp WHERE id = ?";
        
        try (Connection conn = Database.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);

            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Erreur lors de la modification de l'employé : " + e.getMessage());
            throw e;
        }
    }
    


}
