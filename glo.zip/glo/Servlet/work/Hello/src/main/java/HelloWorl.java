package hello ;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class HelloWorl extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<HTML>");
        out.println("<HEAD><TITLE>Bonjour tout le monde</TITLE></HEAD>");
        out.println("<BODY>");
        out.println("<BIG> Hello everybody  </BIG>");
        out.println("</BODY></HTML>");
    }
}
