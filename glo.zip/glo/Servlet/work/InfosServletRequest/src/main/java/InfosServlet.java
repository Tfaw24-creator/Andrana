import java.io.IOException;
import java.servlet.ServletException;
import java.servlet.annotation.WebServlet;
import java.servlet.http.HttpServlet;
import java.servlet.http.HttpServletRequest;
import java.servlet.http.HttpServletResponse;


public class InfosServlet extends HttpServlet {

    public class SimpleCounterServlet extends HttpServlet {
        private int count = 0;
        protected void doGet(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {
        res.setContentType("text/plain");
        PrintWriter out = res.getWriter();
        count++;
        out.println("Depuis son chargement, on a accédé à cette Servlet " +
        count " fois.");
        }
        }
}
